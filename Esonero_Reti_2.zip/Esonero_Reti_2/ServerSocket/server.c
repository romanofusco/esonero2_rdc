#include <stdio.h>
#include <winsock2.h>
#include "calculator.h"

#define DEFAULT_PORT 56700 				//56700 from the trace
#define CLIENT_NAME "cln.di.uniba.it"   //pippo.di.uniba.it from the trace

int main() {

    //initialize Winsock
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        fprintf(stderr, "WSAStartup failed.\n");
        return 1;
    }

    //create a socket for the server
    SOCKET serverSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (serverSocket == INVALID_SOCKET) {
        fprintf(stderr, "Socket creation failed.\n");
        WSACleanup();
        return 1;
    }

    //set up server address structure
    struct sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(DEFAULT_PORT);

    //bind the socket to the server address
    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        fprintf(stderr, "Bind failed.\n");
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    printf("Server is listening on port %d...\n\n", DEFAULT_PORT);

    double result;

    while (1) {

        //set a timeout on receiving
        fd_set readSet;
        struct timeval timeout;
        FD_ZERO(&readSet);
        FD_SET(serverSocket, &readSet);
        timeout.tv_sec = 1;

        int selectResult = select(0, &readSet, NULL, NULL, &timeout);

        if (selectResult == SOCKET_ERROR) {
            fprintf(stderr, "Error in select.\n");
            closesocket(serverSocket);
            WSACleanup();
            return 1;
        }

        if (selectResult == 0) {
            continue;
        }

        //receive data from the client
        struct sockaddr_in clientAddr;
        int addrLen = sizeof(clientAddr);
        char buffer[256];

        int bytesReceived = recvfrom(serverSocket, buffer, sizeof(buffer), 0, (struct sockaddr*)&clientAddr, &addrLen);

        if (bytesReceived == SOCKET_ERROR) {
            fprintf(stderr, "Error in receiving data from the client.\n");
            closesocket(serverSocket);
            WSACleanup();
            return 1;
        }

        char operation = buffer[0];
        double num1, num2;
        memcpy(&num1, buffer + 1, sizeof(double));
        memcpy(&num2, buffer + 1 + sizeof(double), sizeof(double));

        //instead of breaking out of the loop, continue to the next iteration
        if (operation == '=') {
            sendto(serverSocket, "exit", sizeof("exit"), 0, (struct sockaddr*)&clientAddr, sizeof(clientAddr));
            continue;
        }

        char clientInfo[100];
        sprintf(clientInfo, "Request operation '%c %.2lf %.2lf' from client %s, IP %s",
                operation, num1, num2, CLIENT_NAME, inet_ntoa(clientAddr.sin_addr));

        printf("%s\n", clientInfo);

        //perform the calculation based on the operation
        switch (operation) {
            case '+':
                result = add(num1, num2);
                break;
            case '*':
                result = mult(num1, num2);
                break;
            case '-':
                result = sub(num1, num2);
                break;
            case '/':
                result = division(num1, num2);
                break;
            default:
                result = 0;
                break;
        }

        //send the result to the client directly as a double
        sendto(serverSocket, (char*)&result, sizeof(double), 0, (struct sockaddr*)&clientAddr, sizeof(clientAddr));

        char resultMessage[256];
        sprintf(resultMessage, "%.2lf %c %.2lf = %.2lf", num1, operation, num2, result);
        printf("%s\n\n", resultMessage);
    }

    //close server socket
    closesocket(serverSocket);
    WSACleanup();

    return 0;
}
