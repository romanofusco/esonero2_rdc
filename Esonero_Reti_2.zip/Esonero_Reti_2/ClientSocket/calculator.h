#ifndef CALCULATOR_H
#define CALCULATOR_H

//function declarations
double add(double a, double b);
double mult(double a, double b);
double sub(double a, double b);
double division(double a, double b);

#endif //CALCULATOR_H
