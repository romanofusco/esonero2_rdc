#include <stdio.h>
#include <winsock2.h>
#include "calculator.h"

#define DEFAULT_IP "127.0.0.1" 				//192.168.0.11 from the trace
#define DEFAULT_PORT 56700 					//56700 from the trace
#define SERVER_NAME "srv.di.uniba.it"

int main(int argc, char *argv[]) {

    //initialize Winsock
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        fprintf(stderr, "WSAStartup failed.\n");
        return 1;
    }

    //set default server and port
    char serverName[100];
    strcpy(serverName, SERVER_NAME);
    int serverPort = DEFAULT_PORT;

    //check for command line arguments
    if (argc == 2) {
        //parse the command line argument to extract server name and port
        sscanf(argv[1], "%[^:]:%d", serverName, &serverPort);
    }

    //create a socket for the client
    SOCKET clientSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (clientSocket == INVALID_SOCKET) {
        fprintf(stderr, "Socket creation failed.\n");
        WSACleanup();
        return 1;
    }

    //set up server address structure
    struct sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr(DEFAULT_IP);
    serverAddr.sin_port = htons(serverPort);

    char operation;
    double num1, num2, result;

    do {
        //create a buffer to hold the data to be sent
        char sendBuffer[256];

        //get user input for operation or exit
        printf("\nEnter operation (+, *, -, /) or '=' to exit: ");
        if (scanf(" %c", &operation) != 1 || (operation != '+' && operation != '*' && operation != '-' && operation != '/' && operation != '=')) {
            printf("You entered an invalid operator.\n");
            while (getchar() != '\n');
            continue;
        }

        if (operation == '=') {
            break;
        }

        //get user input for two doubles
        if (scanf("%lf %lf", &num1, &num2) != 2) {

            printf("You entered an invalid input for numbers.\n");
            while (getchar() != '\n');
            continue;
        }

        //copy the data into the buffer
        sendBuffer[0] = operation;
        memcpy(sendBuffer + 1, &num1, sizeof(double));
        memcpy(sendBuffer + 1 + sizeof(double), &num2, sizeof(double));

        //send the buffer to the server
        sendto(clientSocket, sendBuffer, sizeof(sendBuffer), 0, (struct sockaddr*)&serverAddr, sizeof(serverAddr));

        //receive the response from the server as a sequence of bytes
        int addrLen = sizeof(serverAddr);
        recvfrom(clientSocket, (char*)&result, sizeof(double), 0, (struct sockaddr*)&serverAddr, &addrLen);

        //display the response on the standard output
        char serverInfo[100];
        snprintf(serverInfo, sizeof(serverInfo), "Received result from the server %s, IP %s: %.2lf %c %.2lf = %.2lf",
                serverName, inet_ntoa(serverAddr.sin_addr), num1, operation, num2, result);

        printf("%s\n", serverInfo);

    } while (operation != '=');

    //close client socket
    closesocket(clientSocket);
    WSACleanup();

    return 0;
}
